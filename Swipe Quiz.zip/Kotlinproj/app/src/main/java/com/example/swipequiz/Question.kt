package com.example.swipequiz

data class Question(
    var questionText: String
)
